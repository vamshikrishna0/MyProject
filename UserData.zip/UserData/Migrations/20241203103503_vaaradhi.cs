﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace UserData.Migrations
{
    /// <inheritdoc />
    public partial class vaaradhi : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Userdata",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Name = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true),
                    Role = table.Column<string>(type: "text", nullable: true),
                    Status = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Userdata", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Userdata",
                columns: new[] { "Id", "Email", "Name", "Role", "Status" },
                values: new object[,]
                {
                    { 1, "Cd project", "Vamshi", "Associate", "Active" },
                    { 2, "Metro", "Krishna", "Intern", "Inactive" },
                    { 3, "Mihoyo", "Genshin", "Developer", "Active" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Userdata");
        }
    }
}
