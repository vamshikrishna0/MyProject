﻿using Microsoft.EntityFrameworkCore;
using UserData.Data;
using UserData.Models;

namespace UserData.Services
{
    public class UserService : IUserService
    {
        private readonly DataContext _Context;

        public UserService(DataContext context)
        {
            _Context = context;
        }

        public  async Task AddUserAsync(Userdata userData)
        {
            _Context.Userdata.Add(userData);
            /* userData.DateCreated = DateTime.UtcNow; */// Set the creation date
            await _Context.SaveChangesAsync();
        }

        public  async Task DeleteUserAsync(int id)
        {
            var userData = await _Context.Userdata.FindAsync(id);
            if (userData != null)
            {
                _Context.Userdata.Remove(userData);
                await _Context.SaveChangesAsync();
            }
        }

        public async  Task<List<Userdata>> GetAllUserAsync()
        {
            var result = await _Context.Userdata.ToListAsync();
            /* .OrderByDescending(s => s.DateUpdated ?? s.DateCreated);*/ // Sort by update date, then creation date
            //var sortedResult = result.OrderByDescending(s => s.DateUpdated ?? s.DateCreated).ToList();
            return result;
        }

        public async Task<Userdata> GetUserByIdAsync(int id)
        {
            var userData = await _Context.Userdata.FindAsync(id);
            return userData;
        }

        public async  Task<List<Userdata>> SearchByNameAsync(string name)
        {
            var userData = await _Context.Userdata
                                      .Where(g => g.Name.ToLower().Contains(name.ToLower()))
                                      .Select(g => new Userdata
                                      {
                                          Id = g.Id,
                                          Name = g.Name,
                                          Email = g.Email,
                                          Role = g.Role,
                                          Status = g.Status,
                                      })
                                      .ToListAsync();

            return userData;
        }

        public  async Task UpdateUserAsync(Userdata userData, int id)
        {
            var dbUser = await _Context.Userdata.FindAsync(id);

            if (dbUser != null)
            {
                dbUser.Name = userData.Name;
                dbUser.Email = userData.Email;
                dbUser.Role = userData.Role;
                dbUser.Status = userData.Status;
                /*game.DateUpdated = DateTime.UtcNow;*/ // Set the creation date
                await _Context.SaveChangesAsync();
            }
        }
    }
}
