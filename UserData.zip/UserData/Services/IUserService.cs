﻿using UserData.Models;

namespace UserData.Services
{
    public interface IUserService
    {
        Task<List<Userdata>> GetAllUserAsync();

        Task<Userdata> GetUserByIdAsync(int id);

        Task<List<Userdata>> SearchByNameAsync(string name);

        Task AddUserAsync(Userdata userData);

        Task UpdateUserAsync(Userdata userData, int id);

        Task DeleteUserAsync(int id);
    }
}
