﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;
using UserData.Models;

namespace UserData.Data
{

    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Userdata>().HasData(
            new Userdata { Id = 1, Name = "Vamshi", Email = "Cd project", Role = "Associate", Status = "Active" },
            new Userdata { Id = 2, Name = "Krishna", Email = "Metro", Role = "Intern", Status = "Inactive" },
                new Userdata { Id = 3, Name = "Genshin", Email = "Mihoyo", Role = "Developer", Status = "Active" }
            );
        }

        public DbSet<Userdata> Userdata { get; set; }
    }
}
